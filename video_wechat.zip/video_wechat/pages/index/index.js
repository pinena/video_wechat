//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    currentSwiper: 0,
    defaultPic: '/images/default.jpg',
    picPathList: [
      {
        type: 'video',
        path: '/images/video.mp4'
      },{
        type: 'img',
        path: '/images/1.jpeg'
      },{
        type: 'img',
        path: '/images/2.jpg'
      },{
        type: 'img',
        path: '/images/3.jpg'
      },{
        type: 'img',
        path: '/images/4.jpg'
      }
    ],
    videoShow: false,
    mdc_show: true
  },
  bindPlay: function (e) {
    let that = this,
      datset = e.currentTarget.dataset || {};
    that.videoContext = wx.createVideoContext("video");
    that.videoContext.pause();
    setTimeout(function () {
      that.videoContext.play()
    }, 150);
    that.setData({
      videoShow: true,
      mdc_show: false
    })

  },
  mdcMove1: function (e) {
    let that = this,
      datset = e.currentTarget.dataset || {};
    if (e.touches[0].clientX > 200) {
      wx.createVideoContext("video", this).pause();
      that.setData({
        videoShow: false,
        mdc_show: true
      })
    }
  },
  returnquanping: function (e) {
    let that = this;
    that.setData({
      videoShow: false,
      mdc_show: true
    })
  },
  //轮播图的切换事件
  swiperChange: function (e) {
    let that = this;
    that.setData({
      currentSwiper: e.detail.current
    });
  },
  onLoad: function () {

  }
  
})
